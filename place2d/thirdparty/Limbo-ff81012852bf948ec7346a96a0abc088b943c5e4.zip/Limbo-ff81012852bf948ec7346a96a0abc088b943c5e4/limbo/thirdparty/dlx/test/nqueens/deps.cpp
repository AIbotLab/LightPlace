#include "../../example/nqueens/NQueens.cpp"
