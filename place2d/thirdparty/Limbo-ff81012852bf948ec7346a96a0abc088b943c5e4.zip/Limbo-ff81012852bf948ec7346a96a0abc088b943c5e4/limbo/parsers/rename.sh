#########################################################################
# File Name: rename.sh
# Author: Yibo Lin
# mail: yibolin@utexas.edu
# Created Time: Thu 16 Oct 2014 12:50:46 AM CDT
#########################################################################
#!/bin/bash

rename 's/^Def/Lp/' *
